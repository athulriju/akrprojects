from django.shortcuts import render, redirect
from .models import Todo
from .forms import Todoform

# Create your views here.

def index(request):
    tasks = Todo.objects.all()
    if request.method == 'POST':
        name = request.POST.get('task',)
        prior = request.POST.get('priority',)
        date = request.POST.get('date',)
        task = Todo(name=name, priority=prior, date=date)
        task.save()
    return render(request, 'index.html', {'tasks': tasks})

def delete(request, id):
    delete = Todo.objects.get(id=id)
    if request.method == 'POST':
        delete.delete()
        return redirect('/')
    return render(request, 'delete.html')


def update(request, id):
    task_update = Todo.objects.get(id=id)
    f = Todoform(request.POST or None, instance=task_update)
    if f.is_valid():
        f.save()
        return redirect('/')
    return render(request, 'update.html', {'f': f})

